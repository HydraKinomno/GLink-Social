<footer class="footer white-text" style="font-size: 16px;">
        <div class="container2">
            <div class="row">
                <div class="col s3 center">
                    <i class="material-icons">home</i>
                    <p>Home</p>
                </div>
                <div class="col s3 center">
                    <i class="material-icons">collections</i>
                    <p>Collections</p>
                </div>
                <div class="col s3 center">
                    <i class="material-icons">people</i>
                    <p>Communities</p>
                </div>
                <div class="col s3 center">
                    <i class="material-icons">notifications</i>
                    <p>Notifications</p>

                </div>
            </div>
        </div>
    </footer>