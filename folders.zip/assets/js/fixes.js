$(document).ready(function() {
      setInterval(function() {
        $('img[src="null"]').hide();
      }, 5); 
  });