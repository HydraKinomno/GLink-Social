<?php
$db_host = "localhost:3306";
$db_user = "root";
$db_pass = "";
$db_name = "glink_main";

$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';

$siteurl = $protocol . "://localhost:2015";

?>
